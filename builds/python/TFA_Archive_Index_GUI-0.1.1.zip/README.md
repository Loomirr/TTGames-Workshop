# TFA archive index

Version 0.1.1. The Force Awakens CC8 DAT / HDR index only. Lists file paths; does not extract models or complete scenes.

Extract this entire ZIP, then double-click **Launch.pyw**. This opens only
this tool's GUI. No other Workshop download or Blender installation is needed.
Install Python 3.10+ with Tcl/Tk first (included in the usual Windows installer).
You can also run `python Launch.pyw` from this folder.

No third-party Python packages are required.

Browse for your own inputs and choose a new output name outside the game/input
folder. Output-folder fields use a save-style picker to name a NEW folder.
Wait for processing to finish before closing. Check the log and output
manifests for skipped/unsupported records, even when the process finishes.
Failed jobs may leave partial output; choose a new output name when retrying.

Game files and external tools are not included. Format support is limited to
the versions described above; a GUI does not expand decoder support.
AI was used to help with this project. See docs/LICENSING.md for reuse notes.
