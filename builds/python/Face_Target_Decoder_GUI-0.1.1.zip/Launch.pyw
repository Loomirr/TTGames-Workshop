from tools.workshop_gui import main
main('Face targets: decode')
