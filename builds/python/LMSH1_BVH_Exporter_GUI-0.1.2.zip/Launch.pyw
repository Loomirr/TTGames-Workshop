from tools.workshop_gui import main
main('LMSH1 decoded animation to BVH')
