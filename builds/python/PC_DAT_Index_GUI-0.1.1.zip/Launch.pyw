from tools.workshop_gui import main
main('PC DAT index')
