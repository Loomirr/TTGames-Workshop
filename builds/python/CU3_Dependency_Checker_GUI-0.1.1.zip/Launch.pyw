from tools.workshop_gui import main
main('CU3 dependency report')
