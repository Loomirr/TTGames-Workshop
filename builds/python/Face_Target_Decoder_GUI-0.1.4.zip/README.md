# Face targets: decode

Version 0.1.4. Reads supported MESH 169/170/175 face GHGs directly. No extraction log is needed. Produces target JSON; this is not a visual face editor.

Extract this entire ZIP, then double-click **Launch.pyw**. This opens only
this tool's GUI. No other Workshop download or Blender installation is needed.
Install Python 3.10+ with Tcl/Tk first (included in the usual Windows installer).
You can also run `python Launch.pyw` from this folder.

No third-party Python packages are required.

Browse for your own inputs and choose a new output name outside the game/input
folder. Output-folder fields use a save-style picker to name a NEW folder.
Wait for processing to finish before closing. Check the log and output
manifests for skipped/unsupported records, even when the process finishes.
Failed jobs may leave partial output; choose a new output name when retrying.

Game files and external tools are not included. Format support is limited to
the versions described above; a GUI does not expand decoder support.
AI was used to help with this project. See docs/LICENSING.md for reuse notes.

For a small diagnostic report instead of the editable offset payload, run:

```text
python formats/cu3/scripts/decode_face_targets.py "path/to/FACE.GHG" --summary --output "new-summary.json"
```

The summary preserves native target IDs, affected vertex counts and source-space
displacement bounds. It does not infer expressions or sample animation timing,
and cannot be used as an input to the native target writer.
