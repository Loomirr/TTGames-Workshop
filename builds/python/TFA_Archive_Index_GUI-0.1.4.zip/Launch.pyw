from tools.workshop_gui import main
main('TFA archive index')
