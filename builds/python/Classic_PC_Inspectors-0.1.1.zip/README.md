# Classic PC inspectors

Read [instructions](formats/classic-pc/README.md). Run the commands from this extracted folder. Python 3.10+ is required; no Blender or third-party Python packages are needed. These are read-only inspectors, not complete scene/model importers.
