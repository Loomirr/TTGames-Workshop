from tools.workshop_gui import main
main('DCSV archive index')
