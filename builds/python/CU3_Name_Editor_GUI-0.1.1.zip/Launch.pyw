from pathlib import Path
import runpy, sys
base = Path(__file__).resolve().parent
sys.path.insert(0, str(base / 'formats/cu3/scripts'))
runpy.run_path(str(base / 'formats/cu3/scripts/cu3_name_editor_gui.py'), run_name='__main__')
