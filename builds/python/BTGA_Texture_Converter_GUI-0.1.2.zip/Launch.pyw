from tools.workshop_gui import main
main('3DS BTGA to DDS / PNG')
