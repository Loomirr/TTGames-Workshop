from tools.workshop_gui import main
main('LMSH1 AN4 decode')
