"""Classic PC inspection backend; see LICENSE."""
