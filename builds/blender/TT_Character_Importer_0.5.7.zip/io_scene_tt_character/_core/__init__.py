"""Bundled shared native readers; no separate addon registration."""
