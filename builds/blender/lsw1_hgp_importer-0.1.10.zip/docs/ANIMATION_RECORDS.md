# LSW1 PC animation records

The source-tree tools can inspect and sample original PC **ANI** and **BSA**
curves, and change one existing channel without rebuilding the file.
This is research support. Blender playback, verified skeleton/face binding,
new clips and in-game export validation remain unfinished.

## Inspect a file

From the repository folder, using Python 3.10 or newer:

```text
python formats/hgp/lsw1/tools/animation_cli.py inspect path/to/Idle.ani --family ANI
python formats/hgp/lsw1/tools/animation_cli.py inspect path/to/Idle.bsa --family BSA --details
```

The report includes the source hash, track/component counts, curve storage
types, extra keys, shared curves and disagreements between stored key times
and lookup masks. `--details` includes the raw time records and decoded values.
Track numbers are stored indices, **not verified bone or facial-shape names**.

## Sample a curve

```text
python formats/hgp/lsw1/tools/animation_cli.py sample path/to/Idle.bsa --family BSA --track 0 --component 0 --time 12.5
```

Time is a **one-based native frame number**, not seconds. The result is a
scalar channel value. It does not move a Blender bone or facial shape.
The lookup masks select the key pair; stored key times and tangents determine
the cubic interpolation. This distinction matters for the original files whose
stored times disagree with their masks.

## Change one existing channel

Use the hash printed by inspection. Track and component numbers start at zero.

```text
python formats/hgp/lsw1/tools/animation_cli.py transform path/to/Idle.ani --family ANI --track 0 --component 0 --scale 0.5 --source-sha256 HASH_FROM_INSPECTION --output path/to/Idle-edited.ani
```

The operation applies `value * scale + offset`; `--offset` defaults to zero.
Tangent values scale too. Compressed offsets are rounded to the existing value
step and refused if they exceed its range. Scaling changes the compressed
channel's two scale factors without expanding or dropping its keys.

Outputs must be new files. Source-hash mismatches, non-finite values, unknown
curve types, overlapping tables and edits to shared curves are refused.
No game installation is changed. This tool does not add tracks, keys, frames,
bones or character references, and it does not assemble a new animation bank.

## Observed layout

Offsets below are file-relative and little-endian. Serialized pointers are
converted by subtracting the word at `0x04`. They are not ordinary file offsets.

| Field | ANI | BSA |
| --- | --- | --- |
| Observed record tag | `0x00`: 2 | `0x00`: 2 |
| Serialized address base | `0x04` | `0x04` |
| Root pointer | `0x08`, maps to `0x0C` | `0x08`, maps to `0x10` |
| Additional header word | absent | `0x0C`: zero in the samples |
| Duration, float32 | `0x0C` | `0x10` |
| Track/component counts, uint16 pair | `0x10`; 9 components | `0x14`; varying components |
| Lookup block count, uint32 | `0x14` | `0x18` |
| Value/type/track-flag pointers | `0x18`, `0x1C`, `0x20` | `0x1C`, `0x20`, `0x24` |
| Value table starts | `0x24` | `0x30` |

Observed block counts equal `ceil((duration - 1) / 32)`. Each channel is either
a constant float32 (type 0), a float-key curve (type 1), or a compressed curve
(type 2). Each animated curve begins with three pointers: frame masks,
uint16 cumulative key counts, and key payload. One uint32 mask covers 32 frames;
the cumulative counts must agree with all preceding masks.

Type 1 has 16-byte records: stored time, reciprocal interval, value and tangent.
Type 2 has two float scales followed by 4-byte records: signed int16 value,
signed int8 tangent, and an unsigned time byte. Scale factors decode values
and tangents separately. A time byte alone is insufficient to recover long clips.

The reader retains raw times and mask frames separately. Sampling reproduces
the observed native scalar evaluator: mask lookup selects a pair, while stored
times determine its interval. Type 1 also uses the stored reciprocal interval;
type 2 uses the raw byte-time difference, including zero or negative differences.
It does not unwrap the bytes or sort anomalous keys. Query times below 1 clamp
to 1; times at or beyond duration clamp to duration minus 0.01. Stored keys,
track flags and padding/trailing bytes remain unchanged.

## Evidence and remaining work

On 22 October 2026, record checks accepted **870 of 871 ANI** and **617 of 617
BSA** original files. `Chars/QuiGonJinn/old/combo1_3a.ani` was rejected for a
non-finite value at `0x708`. No data was silently repaired.

The accepted files contain **2,895 keys beyond the mask-indexed key count** and
**26 curves with stored-time/mask disagreements**. Those records survive edits.
An unchanged operation was byte-identical for every accepted file. **2,446
edited round trips** exercised one channel of every storage type present per
file: decoded values/tangents changed as requested, lengths stayed identical,
and every byte outside the chosen value/tangent fields stayed unchanged.

Synthetic tests cover both headers, extra keys, malformed pointers/counts,
overlapping regions, invalid prefixes, non-finite values, source hashes, shared
curves, offset overflow and output overwrite protection:

```text
python formats/hgp/lsw1/tests/check_animation_records.py
python formats/hgp/lsw1/tests/check_audit_files.py
python formats/hgp/lsw1/tests/check_curve_evaluation.py
```

### Comparison with the original scalar evaluator

An isolated x86 comparison ran **340,724 samples from 1,487 original files**:
96,056 float-key samples and 244,668 compressed-key samples. There were no
differences above the stated tolerance; the largest absolute difference was
0.00000190735. Samples cover early/late key boundaries and fractional frame
times, including the observed anomalous time records. This is sampled numerical
agreement, not proof of exact equality at every possible time.

The comparison executes the original scalar routine at `0x004FA090`, with a
synthesized time context and in-memory pointer relocation. It does not start
the game or exercise the full animation caller. The executable must have SHA-256
`49f74d802596b72b8da24b76f98f249dfdb370d5607fa7e65e3a19beb833d473`;
other executable versions are refused. The time-context builder was inspected,
but has not passed isolated execution. Constant channels are tested directly.

Optional research dependencies: `pefile` and `unicorn` (tested with 2024.8.26 and
2.1.4). With those installed in your research Python environment:

```text
python formats/hgp/lsw1/tools/check_native_curves.py path/to/LEGOSTAR.EXE path/to/extracted-animations path/to/new-comparison.json
```

These checks establish record preservation and scalar evaluation, not playback
or in-game success. Next work is clip ownership, coordinate/rotation conventions,
facial-target binding, definition timing/loop rules, then Blender and in-game
checks. Some ANI files have different track counts from sibling HGPs; even equal
counts do not establish ownership.

### Binding leads still being verified

In the same executable, `0x004C05F0` enumerates selected HGP layer indices into
short integers. The caller at `0x004C1AEC` passes that list to `0x004D5C50`, whose
body at `0x03AF9075` indexes BSA tracks by those layer indices and evaluates each
component. This explains why BSA track counts can differ from facial target
counts. The final correspondence between components and rendered morph targets,
missing-channel defaults and clip ownership still need end-to-end checks before
automatic Blender binding is enabled.

This implementation was derived from local original-file observations with AI
assistance. It does not use a later AN3/AN4 parser or an external implementation.
