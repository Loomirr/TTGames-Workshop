# LSW1 PC shaders and material accuracy

The goal is to reproduce the original game's material calculations and render
states. Matching a texture in Blender is only one part of that work.

## Pod energy beams: fixed opaque backing in 0.1.9

The black rectangle behind pod energy beams came from treating an additive
material as ordinary solid plastic. The original PC code selects **source alpha
plus the existing background** for material blend mode 2. Black adds nothing;
it must not cover what is behind the beam.

The addon now uses a transparent surface plus a camera-visible color contribution
for the observed ordinary mode-2 effect. Texture alpha and vertex opacity scale
that contribution. Eevee uses Blended rendering because its Dithered path drops
the glow when surface coverage is zero. The effect does not illuminate nearby
objects. Auxiliary bump/reflection materials also use mode 2, so they are
excluded from this simple preview rather than turned into glowing surfaces.

This fixes background coverage. **Native beam brightness, shader lighting,
reflections, animated texture coordinates and depth/sorting behavior are not yet
matched end to end.** Existing Blender scenes need a fresh import to receive the
new material. Solid viewport shading does not show these effects.

## Evidence from the executable

The original material-state branch at `0x00520F29` reads the low four bits of
the attribute word at material `+0x40`. For mode 2, it calls the render-state
wrapper at `0x00531A30` with these state/value pairs:

| Render state | Value |
| --- | --- |
| Alpha blending enabled (27) | True (1) |
| Blend operation (171) | Add (1) |
| Source factor (19) | Source alpha (5) |
| Destination factor (20) | One (2) |

These identifiers agree with Microsoft's [render-state definitions](https://learn.microsoft.com/en-us/windows/win32/direct3d9/d3drenderstatetype)
and [blend-factor definitions](https://learn.microsoft.com/en-us/windows/win32/direct3d9/d3dblend).
An isolated x86 check executed the original branch for modes 0, 1 and 2,
intercepting the state wrapper and checking its actual arguments. It did not
start Direct3D or render a game frame.

The original corpus has ten directly used mode-2 primitive parts, including pod
effects and a lightsabre part. All ten use effect ID 0, with no linked auxiliary
material. Many additional material-table entries use mode 2 for other shader
passes; the new preview does not replace those.

Twelve numerical render cases in Cycles and Eevee check black, zero opacity,
partial/full opacity and separate texture alpha against a known background.
Original Anakin and Sebulba pod renders were also inspected. Those checks verify
the Blender blending fix, not identical appearance in the game.

## Original compiled shader inventory

The executable contains compiled shader programs and constant tables. The new
Windows research tool found **294 program entries, representing 161 distinct
bytecode sequences**:

| Profile | Entries |
| --- | --- |
| Vertex shader 1.1 | 38 |
| Vertex shader 2.0 | 109 |
| Pixel shader 1.1 | 32 |
| Pixel shader 1.4 | 1 |
| Pixel shader 2.0 | 114 |

Windows' shader disassembler accepted these entries. Constant tables retain
names for shader inputs such as diffuse/specular samplers and specular strength.
This recovers shader assembly and metadata, **not the original HLSL source**.
The inventory currently requires a leading CTAB comment, so it does not prove
there are no other shader programs or fixed-function paths.

### Connecting materials to those programs

The inventory now also follows **136 observed effect registrations**, covering
**68 effect IDs and 88 effect blob locations (82 distinct contents)**. All 294 inventoried shader
entries fall completely inside those registered blobs. Each report entry keeps
the registration address, blob hash, candidate shaders, technique names and
input names. Several initialization paths register different blobs under the
same ID, so the tool retains all of them.

An HGP material's effect byte is not the final shader ID. The original selector
at `0x0052F300` also examines the geometry and current draw. An isolated check of
**768 combinations** verified these ordinary-material cases:

| Draw condition | Selected effect ID |
| --- | --- |
| Rigid `0x59` geometry, ordinary blend modes | 9 |
| Rigid `0x59` geometry, blend mode 6 | 11 |
| Skin data present, or vertex type `0x5d`, without active morph weights and data together | 15 |
| The same skinning path, with both morph data and active morph weights | 19 |

These results use material effect byte 0 and lighting modes 0, 1 and 3.
Material overrides and the separate multiple-render-target path are disabled.
Lighting mode 2 calls additional runtime helpers and is outside this check.
This is original-code execution with synthetic structures, not a captured draw.
In particular, having facial targets does not mean the morph shader is active.

For effects 9, 15 and 19, the observed registrations include vertex-shader-only
blobs, shader-model-1.1 variants and shader-model-2.0 variants. The last two
contain both `TECHNIQUE_TEXTURE` and `TECHNIQUE_NOTEXTURE`. The inventory identifies
programs inside each blob; it does not yet decode their individual pass bindings
or establish which initialization branch a particular game session uses.

### Color and opacity are separate calculations

The effect constructor maps `SEMANTIC_MATERIALCOLOR` to its parameter slot at
`+0x78`. Executing the original upload branch at `0x0052AC00` with an intercepted
effect setter verified **12 color/texture-handle cases**:

- Without a runtime texture, it uploads the material RGB unchanged.
- With a nonzero runtime texture handle, it uploads half the material RGB.
- In both cases, the uploaded fourth component is 1.

Runtime handle 0 means no texture. It must not be confused with texture index 0
in a serialized HGP, where the first embedded texture is valid.

Inspection of the shader-model-2.0 candidates for effects 9, 15 and 19 shows
three directional lights plus ambient light. Their textured pixel programs
multiply texture color, the supplied material color and lighting, then double
and clamp the result. The halving at upload therefore cancels the doubling of
material RGB. Applying only the pixel program's doubling would make a texture
too bright.

Opacity follows a different path: those vertex programs pass vertex alpha
through, and the pixel programs double and clamp it, also multiplying texture
alpha when textured. The untextured variant doubles only alpha. These are
assembly findings, **not yet a replacement for the addon's opacity preview**:
runtime vertex preparation, fixed-function variants, pass selection and blending
still need to be connected and compared with actual frames. The 157-model corpus
contains 1,268 used textured material records, all with white diffuse RGB, so it
does not provide a colored-texture example to validate tinting in-game.

## Controlled Blender shader experiment

There is now a separate render experiment for the ordinary shader-model-2.0
lighting calculation. It uses three directional lights and an ambient term,
preserves the supplied normal length, applies the verified material-color
upload adjustment, and reproduces the pixel program's RGB/alpha clamps. It also
supports the observed opaque, source-alpha and additive blend equations.

This experiment is **not enabled in the installed addon**. It does not replace
normal maps, reflections or other special effects with an ordinary material.
Those parts retain their existing importer preview and are listed in the report.
The optional effect-129 experiment below handles its verified texture-specular
candidate separately. The normal vectors are stored explicitly for the imported rest pose; moving
bones afterward does not update this experimental normal attribute.

Validation on Blender 5.2.2 LTS:

- A separate arithmetic reference matched **4,608 pixel samples** from a CPU interpreter
  of nine original pixel-program entries: ordinary and texture-specular
  candidates. These contain four distinct pixel bytecodes. A further 512 samples
  checked the specular vertex lookup coordinates against the original rigid
  vertex program.
  Maximum difference was below `2.9e-7`. This is an arithmetic comparison, not
  execution on the original GPU or verification of its partial precision.
- **30 rendered cases** passed in Cycles and Eevee within `0.003` per RGB channel.
  They cover short/non-unit normals, light direction, textured saturation,
  transparency, additive black, texture alpha applied before the alpha clamp,
  separate highlight saturation, lookup alpha independence and display conversion.
- Original Anakin pod comparisons applied the experiment to all 58 selected
  parts. Young Anakin applied it to one part and retained ten special-effect
  parts. Both before/after images were rendered and inspected, and separate
  Blender scenes were saved.

The model comparison uses chosen lights, not recovered level lighting. Its
required `--color-space` argument makes the color-space assumption explicit:
`linear` measures the arithmetic directly; `display` treats the shader's RGB
numbers as display values and converts them to Blender's linear output afterward.
The latter is a hypothesis for visual comparison, **not a recovered sampler or
framebuffer setting**. Blender then composites transparency in its own linear
space. Native blending space, vertex preparation, texture filtering, culling,
shadows and reflections remain unverified. A more saturated or flatter image
does not by itself prove greater game accuracy.

Run this in a fresh background Blender process. It writes `importer-preview.png`,
`shader-experiment.png`, matching `.blend` scenes and `report.json` into a **new**
directory. The two images use the same geometry and camera. The importer version
uses Blender lights; the experiment evaluates its own lighting expression from
the corresponding chosen directions and colors.

```text
blender -b --factory-startup --python-exit-code 1 --python formats/hgp/lsw1/tools/render_shader_comparison.py -- path/to/model.hgp path/to/new-comparison --color-space display
blender -b --factory-startup --python-exit-code 1 --python formats/hgp/lsw1/tests/check_shader_nodes_blender.py -- path/to/new-numerical-test
python formats/hgp/lsw1/tools/check_pixel_programs.py path/to/LEGOSTAR.EXE path/to/new-pixel-check
```

The pixel check uses the shader inventory's optional dependencies and keeps its
original disassembly inside the supplied private output directory. The render
experiment needs Blender and the repository source, without the executable or
additional research libraries. These scripts live outside the installable addon.

### Character highlights: separate texture-specular experiment

The original effect-129 selector, with advanced lighting disabled, returns
candidate 2 for rigid parts and 17 for skinned parts without active morphs.
Active morph data plus weights returns 0 in this branch; it is not silently
substituted with the ordinary morph shader. Together with the ordinary cases,
the native selector check covers 1,536 synthetic combinations.

The parameter upload at `0x0052B0B4` reads the linked material's red component
and multiplies it by 0.1. Six intercepted original-code calls verify this. The
pixel program clamps twice the sampled lookup RGB times that strength, then
adds it to the diffuse result without clamping the sum. Lookup alpha does not
change surface opacity. The vertex program computes lookup UVs from the
transformed normal and a supplied four-row matrix, normalizing all four resulting
components before scaling XY into 0–1. UVs are computed per vertex, not from a
renormalized per-pixel normal.

To opt into this experiment, supply `--specular-matrix path/to/matrix.json` with
four arrays of four numbers. This is an explicit input hypothesis: runtime
matrix construction, advanced reflections, filtering and active pass selection
are still unresolved. The script flips the resulting V for Blender's image
coordinates. Do not describe these scenes as fully accurate game captures.

Original Clone comparisons cover all 17 selected parts with the ordinary path;
Stormtrooper covers all six with the texture-specular candidate. Use
`--preview-pose` for the reversible hand display correction in 0.1.10. Without
it these models retain their short native hand bind, exposing the known wrist
intersection. Other preview poses involving rotation are refused by this static
normal experiment.

### Shader inventory correction

The scanner now walks shader-model-2/3 instruction lengths and skips complete
comment blocks. END-looking values inside constant tables, embedded preshader
metadata or instruction operands no longer truncate the program. This recovers
97 additional entries: **294 entries and 161 distinct bytecodes** in total.
Legacy shader-model-1 scanning still uses a bounded scan and disassembler check.
A recovered program is not yet a reconstructed effect or a proven active pass.

The executable used for the native checks has SHA-256
`49f74d802596b72b8da24b76f98f249dfdb370d5607fa7e65e3a19beb833d473`.
Other versions are explicitly refused by these research tools. Original shader
assembly stays in the caller's private output directory.

```text
python formats/hgp/lsw1/tools/inspect_native_shaders.py path/to/LEGOSTAR.EXE path/to/new-private-shader-folder --disassembly
python formats/hgp/lsw1/tools/check_native_materials.py path/to/LEGOSTAR.EXE path/to/new-state-report.json
python formats/hgp/lsw1/tools/check_native_effects.py path/to/LEGOSTAR.EXE path/to/new-effect-report.json
blender -b --factory-startup --python-exit-code 1 --python formats/hgp/lsw1/tests/check_additive_blender.py -- path/to/new-render-test
```

The inventory needs Windows, `pefile` and the system `D3DCompiler_47.dll`.
The state/color and selector checks additionally need `unicorn`. These are optional research tools;
the Blender addon does not load the game executable or require those libraries.
Asset-free registration tests cover alternative blobs for one ID, malformed
ranges, object IDs, signatures and shaders crossing an effect boundary.

## What remains for a full match

1. Complete the verified ordinary-effect selection with runtime initialization,
   technique/pass bindings and special effects. An effect number or matching
   sampler name alone is insufficient.
2. Recover runtime constants, vertex colors, light inputs, texture transforms
   and multi-pass ordering, including normal/reflection and facial surfaces.
3. Extend the controlled ordinary-shader experiment to verified runtime inputs
   and special passes. Record engine behavior that Blender materials cannot match.
4. Compare game captures and Blender renders with matching models, poses,
   camera, textures and lighting. Check animated frames and transitions too.

AI assistance was used for implementation and original-code analysis. No
frame-matched full-shader fidelity result is claimed yet.
