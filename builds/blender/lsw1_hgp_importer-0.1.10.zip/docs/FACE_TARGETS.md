# LSW1 PC facial shape targets

Version 0.1.7 imports the observed native position targets as Blender shape
keys. Basis is unchanged and every target starts at zero. IDs are shown as
`morph N`; names such as blink or smile have not been established.

## What was checked

The original-file reader passed 157 HGP files across 575 stored layers. Of those,
63 files contained 164 morph blocks, with 1,183 populated targets and 460 empty
target slots. All observed blocks used skinned vertex layout `0x5D`.

Blender 5.2.2 imported all 63 files with every native layer included for the test.
All 1,643 target slots were checked against source bytes, including per-primitive
vertex remapping, unchanged Basis, zero initial values and empty slots. One
populated target on each of the 164 facial mesh parts was checked through
Blender's evaluated armature. Cleanup left no orphaned shape-key data.

Basis and one populated target were also rendered and visually inspected for
Yoda, Qui-Gon Jinn and Young Anakin with identical cameras and lighting per pair
(Cycles, 32 samples, Standard view transform). The mouth poses visibly changed.
These were manual native-target poses, not game clip playback or a comparison
against the original game's rendering.

These checks establish import and evaluated displacement. They do not establish
BSA playback, game export, normal deformation fidelity or matching game shaders.

## Observed storage

Offsets below are relative to the body after the 0x30-byte file header. They
describe the tested original PC files, not LSW2, TCS or another platform.

Geometry word `+0x3C` points to a 20-byte record, or is zero when absent:

| Word | Observed contents |
| --- | --- |
| 0 | Number of target slots |
| 1 | Pointer to that many 32-bit target-data pointers |
| 2 | Pointer to that many 32-bit target IDs |
| 3 | Start of position-delta data |
| 4 | Unknown; retained as inspection metadata |

Each nonzero target pointer addresses XYZ float32 deltas for **every vertex in
the geometry's source buffer**. A zero pointer is an empty target. The target
arrays are contiguous, followed by the pointer table, the ID table and the record.
The observed IDs run from zero to count minus one. The reader rejects other
arrangements until original-file evidence supports them; allocation and finite
value checks also apply.

Primitives can use only a subset of that buffer. Import maps deltas through the
same original vertex indices as positions and weights, then applies the same
coordinate conversion. Taking the first N deltas for a primitive would move the
wrong vertices. Geometry `+0x38` is a different field and is not used as the morph
pointer. The record's last word is not assumed to identify a vertex buffer.

## Reproduce

Asset-free malformed-layout and primitive-remapping checks:

```text
python formats/hgp/lsw1/tests/check_morph_targets.py
```

Original-file and evaluated Blender checks, with your extracted HGP folder and
a new output directory:

```text
blender --background --factory-startup --python-exit-code 1 --python formats/hgp/lsw1/tests/check_morphs_blender.py -- extracted-folder new-output
```

The next step is proving which BSA channels drive which model and target, then
checking interpolation and visible results. Matching counts or IDs alone does
not establish that relationship. Native facial export remains unimplemented.
