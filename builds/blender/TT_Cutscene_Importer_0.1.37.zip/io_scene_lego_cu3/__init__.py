bl_info = {
    'name': 'LEGO CU3 Cutscene Importer (Experimental)',
    'author': 'Loomirr',
    'version': (0, 1, 37),
    'blender': (4, 4, 0),
    'location': 'File > Import > LEGO CU3 cutscene',
    'description': 'Assemble supported cutscene actors, attachments, materials and cameras from native companion assets',
    'category': 'Import-Export',
}

import bpy
from bpy.props import StringProperty, EnumProperty, IntProperty, BoolProperty
from bpy_extras.io_utils import ImportHelper
from .cu3 import Cutscene, FormatError
from .skeleton import read_skeleton
from .cinematic import visibility
from .blender_import import inspect_scene, create_rig, duplicate_rig, check_rig, apply_pose, apply_actor_visibility, prepare_pose


class TT_CU3_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__
    lb3_asset_root: StringProperty(name='Batman 3 game or asset folder', subtype='DIR_PATH')
    lmsh1_asset_root: StringProperty(name='Marvel Super Heroes game or asset folder', subtype='DIR_PATH')
    cache_root: StringProperty(name='Extracted companion cache', subtype='DIR_PATH', description='Optional cache outside installed games; blank uses the local TTGamesWorkshop asset cache')

    def draw(self, context):
        self.layout.label(text='Saved companion folders for scene imports')
        self.layout.prop(self,'lb3_asset_root')
        self.layout.prop(self,'lmsh1_asset_root')
        self.layout.prop(self,'cache_root')
        self.layout.label(text='Installed game folders: extracts needed companions automatically.')
        self.layout.label(text='CU3 stores animation/references; models and textures are separate files.')


def assembly_profile(cut, requested):
    if requested != 'AUTO':return requested
    profile = {16:'LMSH1',17:'LMSH1',18:'LMSH1',19:'LB3'}.get(cut.version)
    if profile is None:
        raise FormatError(f'Full scene assembly is not implemented for CU3 version {cut.version}. Inspect scene references is available separately; it does not create meshes.')
    return profile


class IMPORT_SCENE_OT_lego_cu3(bpy.types.Operator, ImportHelper):
    bl_idname = 'import_scene.lego_cu3'
    bl_label = 'Import LEGO CU3 cutscene'
    bl_options = {'REGISTER', 'UNDO'}
    filename_ext = '.cu3'
    filter_glob: StringProperty(default='*.cu3;*.CU3', options={'HIDDEN'})
    mode: EnumProperty(name='Import mode', items=[
        ('ASSEMBLE', 'Assemble available scene assets', 'Import actors, costume materials and cameras from an installed game or extracted asset folder; report missing systems'),
        ('DEPENDENCIES', 'Check companion files', 'Report character definitions, models, active attachments and costume textures before building a scene'),
        ('INSPECT', 'Inspect scene references', 'Read actor names, timeline and source data report'),
        ('SKELETONS', 'Create source armatures', 'Create armatures for actors matching the supplied GHG/JSON source skeleton'),
        ('SELECTED', 'Animate selected source rig', 'Apply one actor track to a compatible source armature')], default='ASSEMBLE')
    skeleton_path: StringProperty(name='Source skeleton GHG / JSON', subtype='FILE_PATH', description='Uncompressed matching GHG or extracted source skeleton JSON')
    actor_filter: StringProperty(name='Actor name / filter', description='Exact actor name, or substring; required to identify one actor when animating a selected rig')
    record_index: IntProperty(name='Animation record', default=0, min=0)
    copy_rig: BoolProperty(name='Work on a copy', default=True)
    place_in_scene: BoolProperty(name='Use source scene movement', default=False, description='Apply static or animated actor placement separately from skeletal motion')
    source_visibility: BoolProperty(name='Use source visibility', default=True, description='Hide shot-specific character instances and their children according to source tracks')
    asset_root: StringProperty(name='Game or extracted asset folder', subtype='DIR_PATH')
    static_environment: BoolProperty(name='Recovered static environment (experimental)', default=True, description='Build bounded static stage draws from declared level resources; visibility, nested scenes and source lighting remain incomplete')
    game_profile: EnumProperty(name='Game (PC)', items=[('AUTO','Detect supported game','Detect supported Marvel Super Heroes / Batman 3 CU3 versions; other games require reference inspection'),('LB3','LEGO Batman 3','PC DX11 models with NXG animations'),('LMSH1','LEGO Marvel Super Heroes','PC NXG models and animations')], default='AUTO')
    cameras: BoolProperty(name='Import source cameras', default=False, description='Import observed source camera tracks and shot markers into the current scene')

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text='1. Choose what to import', icon='SCENE_DATA')
        box.prop(self, 'mode', text='Task')
        if self.mode in ('ASSEMBLE','DEPENDENCIES'):
            box = layout.box()
            box.label(text='2. Choose the game and files')
            box.prop(self, 'game_profile')
            box.prop(self, 'asset_root', text='Game folder')
            box.label(text='Blank folder: use the saved game folder.')
            box = layout.box()
            if self.mode=='ASSEMBLE':
                box.prop(self,'static_environment', text='Include stage geometry (experimental)')
                box.label(text='Creates a separate scene.')
                box.label(text='Lighting, props and effects are incomplete.')
            else:
                box.label(text='Checks files without creating meshes.')
        elif self.mode != 'INSPECT':
            box = layout.box()
            box.label(text='Advanced: match a source rig')
            box.prop(self, 'skeleton_path')
            box.prop(self, 'actor_filter')
            box.prop(self, 'record_index')
            box.prop(self, 'place_in_scene')
            box.prop(self, 'source_visibility')
            if self.mode == 'SELECTED':
                box.prop(self, 'copy_rig')
        else:
            layout.label(text='Creates markers and a text report.')
            layout.label(text='No character meshes in this mode.')
            layout.label(text='Use this for Force Awakens / DC Super-Villains.')
        if self.mode not in ('ASSEMBLE','DEPENDENCIES'):layout.prop(self, 'cameras')

    def invoke(self, context, event):
        if self.filepath:
            return context.window_manager.invoke_props_dialog(self, width=520)
        return ImportHelper.invoke(self, context, event)

    def execute(self, context):
        try:
            cut = Cutscene(self.filepath)
            source = context.view_layer.objects.active
            if self.mode in ('ASSEMBLE','DEPENDENCIES'):
                profile = assembly_profile(cut,self.game_profile)
                addon = context.preferences.addons.get(__package__)
                preferences = addon.preferences if addon else None
                preference_field = 'lb3_asset_root' if profile=='LB3' else 'lmsh1_asset_root'
                asset_root = self.asset_root.strip() or (getattr(preferences,preference_field,'') if preferences else '')
                if not asset_root:
                    raise FormatError('Choose the installed game or extracted asset folder once; it is remembered for this game. CU3 alone does not contain the companion meshes and textures.')
                asset_root = bpy.path.abspath(asset_root)
                from .asset_index import open_assets
                cache_root = getattr(preferences,'cache_root','') if preferences else ''
                assets = open_assets(asset_root, profile, bpy.path.abspath(cache_root) if cache_root else None)
                if preferences and self.asset_root.strip():
                    setattr(preferences,preference_field,asset_root)
            if self.mode == 'DEPENDENCIES':
                import json
                from .dependencies import dependency_report
                from .scene_inputs import prepare_resources
                resolver, configuration = prepare_resources(cut, assets, profile)
                report = dependency_report(cut, resolver)
                report['configuration'] = configuration
                if hasattr(assets,'get_info'):report['asset_source'] = assets.get_info()
                text = bpy.data.texts.new(cut.name+' / companion files')
                text.write(json.dumps(report,indent=2))
                self.report({'INFO'}, f'{report["resolved_resources"]} resources found; {report["missing_resources"]} missing, {report["unresolved_resources"]} unresolved. See "{text.name}" in Text Editor.')
                return {'FINISHED'}
            if self.mode == 'ASSEMBLE':
                from .scene_assembly import assemble
                from .playback_ui import show_scene, prepare_saved_preview
                scene, report = assemble(cut, asset_root, profile, context, assets=assets, static_environment=self.static_environment)
                prepare_saved_preview(context,scene)
                if context.area and context.area.type=='VIEW_3D':show_scene(context, scene)
                self.report({'WARNING'}, f'Imported {len(report["actors"])} model instances; see "{scene["tt_import_report"]}" for missing assets and systems')
                return {'FINISHED'}
            if self.cameras:
                from .cinematic_blender import import_cameras
                import_cameras(cut, context.scene)
            if self.mode == 'INSPECT':
                inspect_scene(cut, context.scene)
                if not cut.actors:
                    self.report({'WARNING'}, 'No actors in this CU3. It may be a control/audio-only file; choose an animated A/B/C segment if present.')
                else:self.report({'INFO'}, f'{cut.name}: {len(cut.actors)} actor nodes, {cut.frames} frames at {cut.fps:g} FPS')
                return {'FINISHED'}
            if not self.skeleton_path:
                raise FormatError('Choose the matching source skeleton GHG or JSON')
            rigdata = read_skeleton(bpy.path.abspath(self.skeleton_path))
            actors = [a for a in cut.actors if len(a['records']) > self.record_index and
                      a['records'][self.record_index]['animation'].nodes == len(rigdata['joints'])]
            exact = [a for a in actors if a['name'].lower() == self.actor_filter.lower()]
            actors = exact or [a for a in actors if self.actor_filter.lower() in a['name'].lower()]
            if not actors:
                counts=sorted({a['records'][self.record_index]['animation'].nodes for a in cut.actors if len(a['records'])>self.record_index})
                if not counts:
                    raise FormatError('No animated actor record in this CU3. Choose an animated segment (often A/B/C) or another record index.')
                raise FormatError(f'No matching actor/skeleton/record: source rig has {len(rigdata["joints"])} joints; this record has joint counts {counts}. Inspect actor names and use a matching source GHG.')
            if self.mode == 'SELECTED':
                if len(actors) != 1:
                    raise FormatError('Use an exact actor name: this filter matches multiple actors')
                if source is None:
                    raise FormatError('Select the matching source armature before importing')
                check_rig(source, rigdata)
            # Validate supported records before changing scene data.
            for a in actors:
                prepare_pose(a['records'][self.record_index]['animation'])
                if self.source_visibility or self.place_in_scene:
                    outer = a.get('visibility_animation')
                    if outer:
                        outer.prepare(scene_channels=True)
                if self.source_visibility:
                    visibility(cut, a)
            collection = inspect_scene(cut, context.scene)
            for a in actors:
                if self.mode == 'SELECTED':
                    rig = duplicate_rig(source, 'CU3 / ' + a['name'], collection) if self.copy_rig else source
                else:
                    rig = create_rig(rigdata, 'CU3 / ' + a['name'], collection)
                apply_pose(cut, a, self.record_index, rig, rigdata, self.place_in_scene, scene_channels=True)
                if self.source_visibility:
                    apply_actor_visibility(cut, a, [rig] + list(rig.children_recursive))
            context.scene.frame_set(1)
            self.report({'INFO'}, f'Imported {len(actors)} source skeletal track(s); scene systems remain experimental')
            return {'FINISHED'}
        except (ValueError, OSError, UnicodeError, KeyError) as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}


class IMPORT_SCENE_OT_lego_cu2(bpy.types.Operator, ImportHelper):
    bl_idname='import_scene.lego_cu2_references'
    bl_label='LEGO CU2 references (classic PC; inspection only)'
    bl_options={'REGISTER','UNDO'}
    filter_glob: StringProperty(default='*.cu2;*.CU2',options={'HIDDEN'})

    def draw(self,context):
        self.layout.label(text='Source placements, names and shot markers.')
        self.layout.label(text='No animated cameras, actors or stage assembly yet.')

    def invoke(self, context, event):
        if self.filepath:
            return context.window_manager.invoke_props_dialog(self, width=520)
        return ImportHelper.invoke(self, context, event)

    def execute(self,context):
        from ._classic.blender_inspect import inspect_cutscene
        try:
            scene,report=inspect_cutscene(context,self.filepath)
        except (ValueError,OSError,RuntimeError) as error:
            self.report({'ERROR'},str(error));return {'CANCELLED'}
        self.report({'WARNING'},'CU2 reference scene created; full playback and companion assembly are not implemented. See CU2 report.')
        return {'FINISHED'}


class TTCU3_FH_cutscene(bpy.types.FileHandler):
    bl_idname = 'TTCU3_FH_cutscene'
    bl_label = 'TT CU3 Cutscene'
    bl_import_operator = 'import_scene.lego_cu3'
    bl_file_extensions = '.cu3'

    @classmethod
    def poll_drop(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D' and context.mode == 'OBJECT'


class TTCU2_FH_cutscene(bpy.types.FileHandler):
    bl_idname = 'TTCU2_FH_cutscene'
    bl_label = 'TT CU2 References'
    bl_import_operator = 'import_scene.lego_cu2_references'
    bl_file_extensions = '.cu2'

    @classmethod
    def poll_drop(cls, context):
        return TTCU3_FH_cutscene.poll_drop(context)


def menu_import(self, context):
    self.layout.operator(IMPORT_SCENE_OT_lego_cu3.bl_idname, text='LEGO CU3 cutscene (.cu3) [experimental]')
    self.layout.operator(IMPORT_SCENE_OT_lego_cu2.bl_idname)


def register():
    from . import face_edit_ui, face_preview_ui, playback_ui
    bpy.utils.register_class(TT_CU3_Preferences)
    bpy.utils.register_class(IMPORT_SCENE_OT_lego_cu3)
    bpy.utils.register_class(IMPORT_SCENE_OT_lego_cu2)
    bpy.utils.register_class(TTCU3_FH_cutscene)
    bpy.utils.register_class(TTCU2_FH_cutscene)
    bpy.types.TOPBAR_MT_file_import.append(menu_import)
    face_edit_ui.register()
    face_preview_ui.register()
    playback_ui.register()


def unregister():
    from . import face_edit_ui, face_preview_ui, playback_ui
    playback_ui.unregister()
    face_preview_ui.unregister()
    face_edit_ui.unregister()
    bpy.types.TOPBAR_MT_file_import.remove(menu_import)
    bpy.utils.unregister_class(TTCU2_FH_cutscene)
    bpy.utils.unregister_class(TTCU3_FH_cutscene)
    bpy.utils.unregister_class(IMPORT_SCENE_OT_lego_cu3)
    bpy.utils.unregister_class(IMPORT_SCENE_OT_lego_cu2)
    bpy.utils.unregister_class(TT_CU3_Preferences)
